Export the rigging
-------------------


1) Select the rigged (and parented) base mesh.
2) File -> Export -> MakeHuman rigging (.json)



Import the rigging
-------------------

1) Select the unrigged (and unparented) base mesh.
2) File -> Import -> MakeHuman rigging (.json)
